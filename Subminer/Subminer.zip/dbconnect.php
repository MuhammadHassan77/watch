<?php
// $mysqli = new mysqli("localhost", "u538897927_sub", "Zaib@123", "u538897927_submariner");

$mysqli = new mysqli("localhost", "root", "", "newwatch");

// $mysqli = new mysqli("localhost", "mwnn", "SGvGx3i3KWTSiBteCNwF", "wp_mwnn");

?>